/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionChange_Server;
    QWidget *centralWidget;
    QTextBrowser *txtbox;
    QLineEdit *txtbox2;
    QPushButton *pushbtn;
    QCheckBox *autoScroll;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1038, 573);
        actionChange_Server = new QAction(MainWindow);
        actionChange_Server->setObjectName(QStringLiteral("actionChange_Server"));
        actionChange_Server->setCheckable(false);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        txtbox = new QTextBrowser(centralWidget);
        txtbox->setObjectName(QStringLiteral("txtbox"));
        txtbox->setGeometry(QRect(10, 40, 1021, 381));
        QFont font;
        font.setFamily(QStringLiteral("Courier New"));
        txtbox->setFont(font);
        txtbox->setReadOnly(true);
        txtbox->setOpenExternalLinks(true);
        txtbox2 = new QLineEdit(centralWidget);
        txtbox2->setObjectName(QStringLiteral("txtbox2"));
        txtbox2->setGeometry(QRect(10, 441, 921, 21));
        txtbox2->setFont(font);
        pushbtn = new QPushButton(centralWidget);
        pushbtn->setObjectName(QStringLiteral("pushbtn"));
        pushbtn->setGeometry(QRect(940, 440, 71, 21));
        autoScroll = new QCheckBox(centralWidget);
        autoScroll->setObjectName(QStringLiteral("autoScroll"));
        autoScroll->setGeometry(QRect(10, 10, 82, 21));
        autoScroll->setChecked(true);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1038, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "RBXChat Client", 0));
        actionChange_Server->setText(QApplication::translate("MainWindow", "Change Server...", 0));
        pushbtn->setText(QApplication::translate("MainWindow", "Send", 0));
        autoScroll->setText(QApplication::translate("MainWindow", "Autoscroll", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
