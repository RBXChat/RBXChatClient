#ifndef UNPWPROMPT_H
#define UNPWPROMPT_H

namespace Ui {
class UNPWPrompt;
}
class UNPWPrompt : public QDialog {
    Q_OBJECT

};

#endif // UNPWPROMPT_H
